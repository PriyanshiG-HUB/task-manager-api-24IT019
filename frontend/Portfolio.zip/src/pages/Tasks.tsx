import { FormEvent, useEffect, useState } from "react";
import {
  createTask,
  deleteTask,
  getTasks,
  Task,
  updateTask,
} from "../lib/api";

export default function Tasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high">(
    "medium"
  );

  const [editingId, setEditingId] = useState<string | null>(null);

  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editPriority, setEditPriority] = useState<
    "low" | "medium" | "high"
  >("medium");

  async function loadTasks() {
    try {
      setLoading(true);
      setError("");

      const data = await getTasks();
      setTasks(data);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to load tasks"
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTasks();
  }, []);

  async function handleCreateTask(event: FormEvent) {
    event.preventDefault();

    if (!title.trim()) {
      setError("Task title is required");
      return;
    }

    try {
      setError("");

      const newTask = await createTask({
        title: title.trim(),
        description: description.trim(),
        priority,
      });

      setTasks((currentTasks) => [newTask, ...currentTasks]);

      setTitle("");
      setDescription("");
      setPriority("medium");
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to create task"
      );
    }
  }

  function startEditing(task: Task) {
    setEditingId(task._id);
    setEditTitle(task.title);
    setEditDescription(task.description || "");
    setEditPriority(task.priority);
  }

  function cancelEditing() {
    setEditingId(null);
    setEditTitle("");
    setEditDescription("");
    setEditPriority("medium");
  }

  async function handleUpdateTask(event: FormEvent) {
    event.preventDefault();

    if (!editingId || !editTitle.trim()) {
      setError("Task title is required");
      return;
    }

    try {
      setError("");

      const updatedTask = await updateTask(editingId, {
        title: editTitle.trim(),
        description: editDescription.trim(),
        priority: editPriority,
      });

      setTasks((currentTasks) =>
        currentTasks.map((task) =>
          task._id === editingId ? updatedTask : task
        )
      );

      cancelEditing();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to update task"
      );
    }
  }

  async function handleToggleComplete(task: Task) {
    try {
      setError("");

      const updatedTask = await updateTask(task._id, {
        title: task.title,
        description: task.description || "",
        priority: task.priority,
        completed: !task.completed,
      });

      setTasks((currentTasks) =>
        currentTasks.map((item) =>
          item._id === task._id ? updatedTask : item
        )
      );
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Failed to update task status"
      );
    }
  }

  async function handleDeleteTask(id: string) {
    const confirmed = window.confirm(
      "Are you sure you want to delete this task?"
    );

    if (!confirmed) {
      return;
    }

    try {
      setError("");

      await deleteTask(id);

      setTasks((currentTasks) =>
        currentTasks.filter((task) => task._id !== id)
      );
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to delete task"
      );
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 px-6 py-12">
      <div className="mx-auto max-w-6xl">
        <div className="mb-10">
          <p className="mb-2 text-sm font-semibold uppercase tracking-wider text-blue-600">
            Practical 6
          </p>

          <h1 className="text-4xl font-bold text-slate-900">
            Task Manager
          </h1>

          <p className="mt-3 max-w-2xl text-slate-600">
            Manage tasks using the React frontend connected to the
            Node.js, Express, and MongoDB REST API.
          </p>
        </div>

        {error && (
          <div className="mb-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-700">
            {error}
          </div>
        )}

        {/* Create Task */}
        <section className="mb-10 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <h2 className="mb-5 text-xl font-semibold text-slate-900">
            Create New Task
          </h2>

          <form onSubmit={handleCreateTask} className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Title
              </label>

              <input
                type="text"
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Enter task title"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Description
              </label>

              <textarea
                value={description}
                onChange={(event) =>
                  setDescription(event.target.value)
                }
                placeholder="Enter task description"
                rows={3}
                className="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Priority
              </label>

              <select
                value={priority}
                onChange={(event) =>
                  setPriority(
                    event.target.value as "low" | "medium" | "high"
                  )
                }
                className="rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>

            <button
              type="submit"
              className="rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white transition hover:bg-blue-700"
            >
              Add Task
            </button>
          </form>
        </section>

        {/* Tasks */}
        <section>
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-900">
              Your Tasks
            </h2>

            <button
              onClick={loadTasks}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100"
            >
              Refresh
            </button>
          </div>

          {loading ? (
            <div className="rounded-2xl bg-white p-10 text-center shadow-sm">
              <p className="text-slate-500">Loading tasks...</p>
            </div>
          ) : tasks.length === 0 ? (
            <div className="rounded-2xl bg-white p-10 text-center shadow-sm ring-1 ring-slate-200">
              <p className="text-lg font-medium text-slate-700">
                No tasks found
              </p>

              <p className="mt-2 text-slate-500">
                Create your first task using the form above.
              </p>
            </div>
          ) : (
            <div className="grid gap-5">
              {tasks.map((task) => (
                <article
                  key={task._id}
                  className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200"
                >
                  {editingId === task._id ? (
                    <form
                      onSubmit={handleUpdateTask}
                      className="space-y-4"
                    >
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(event) =>
                          setEditTitle(event.target.value)
                        }
                        className="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
                      />

                      <textarea
                        value={editDescription}
                        onChange={(event) =>
                          setEditDescription(event.target.value)
                        }
                        rows={3}
                        className="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
                      />

                      <select
                        value={editPriority}
                        onChange={(event) =>
                          setEditPriority(
                            event.target.value as
                              | "low"
                              | "medium"
                              | "high"
                          )
                        }
                        className="rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-blue-500"
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                      </select>

                      <div className="flex gap-3">
                        <button
                          type="submit"
                          className="rounded-lg bg-blue-600 px-5 py-2 font-medium text-white hover:bg-blue-700"
                        >
                          Save Changes
                        </button>

                        <button
                          type="button"
                          onClick={cancelEditing}
                          className="rounded-lg border border-slate-300 px-5 py-2 font-medium text-slate-700 hover:bg-slate-100"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  ) : (
                    <>
                      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-3">
                            <h3
                              className={`text-xl font-semibold ${
                                task.completed
                                  ? "text-slate-400 line-through"
                                  : "text-slate-900"
                              }`}
                            >
                              {task.title}
                            </h3>

                            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold uppercase text-slate-600">
                              {task.priority}
                            </span>

                            <span
                              className={`rounded-full px-3 py-1 text-xs font-semibold ${
                                task.completed
                                  ? "bg-green-100 text-green-700"
                                  : "bg-yellow-100 text-yellow-700"
                              }`}
                            >
                              {task.completed
                                ? "Completed"
                                : "Pending"}
                            </span>
                          </div>

                          {task.description && (
                            <p className="mt-3 text-slate-600">
                              {task.description}
                            </p>
                          )}

                          {task.createdAt && (
                            <p className="mt-3 text-xs text-slate-400">
                              Created:{" "}
                              {new Date(
                                task.createdAt
                              ).toLocaleString()}
                            </p>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <button
                            onClick={() =>
                              handleToggleComplete(task)
                            }
                            className="rounded-lg border border-green-300 px-4 py-2 text-sm font-medium text-green-700 hover:bg-green-50"
                          >
                            {task.completed
                              ? "Mark Pending"
                              : "Complete"}
                          </button>

                          <button
                            onClick={() => startEditing(task)}
                            className="rounded-lg border border-blue-300 px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50"
                          >
                            Edit
                          </button>

                          <button
                            onClick={() =>
                              handleDeleteTask(task._id)
                            }
                            className="rounded-lg border border-red-300 px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}